import requests
import json

url = "http://192.168.202.131/api/v2.0.0/status"

payload  = {}
headers = {
  'Authorization': 'Basic YWRtaW46OGM2OTc2ZTViNTQxMDQxNWJkZTkwOGJkNGRlZTE1ZGZiMTY3YTljODczZmM0YmI4YTgxZjZmMmFiNDQ4YTkxOA==',
  'Content-Type': 'application/json'
}

response = requests.request("GET", url, headers=headers, data = payload)

parsed = json.loads(response.text)
print(json.dumps(parsed,indent=4))

# Fehler löschen
payload  = "{\"clear_error\":true}"

response = requests.request("PUT", url, headers=headers, data = payload)

parsed = json.loads(response.text)
print(json.dumps(parsed,indent=4))


# Status PAUSE
#payload  = "{\"state_id\":4}"

# Status PLAY
payload  = "{\"state_id\":3}"

response = requests.request("PUT", url, headers=headers, data = payload)

parsed = json.loads(response.text)
print(json.dumps(parsed,indent=4))
