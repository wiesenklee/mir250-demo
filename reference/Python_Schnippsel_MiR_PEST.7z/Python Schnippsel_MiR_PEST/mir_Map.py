import requests
import json
import base64

robot_ip = "192.168.4.60"
url = "http://" + robot_ip + "/api/v2.0.0/"
payload  = {}
# =======================
# User: "admin" mit pw "admin" muss im Roboter angelegt sein
# Authorization kann vom MiR (help/api documentation) erstellt werden
# =======================
headers = {
  'Authorization': 'Basic YWRtaW46OGM2OTc2ZTViNTQxMDQxNWJkZTkwOGJkNGRlZTE1ZGZiMTY3YTljODczZmM0YmI4YTgxZjZmMmFiNDQ4YTkxOA=='
}

# ================================
#  Roboter Status abfragen
# ================================
response = requests.request("GET", url + "status", headers = headers, data = payload)
robot_Status = json.loads(response.text)
json.dump(robot_Status,open('mir_status.json','w'),indent = 4,sort_keys = True)

# =================================
#  die Map GUID erhält man über /status oder /maps. 
# =================================
map_guid = robot_Status["map_id"]

# ================================
#  Kartendaten abfragen
# ================================
response = requests.request("GET", url + "maps/" + map_guid, headers = headers, data = payload)

# ================================
#  JSON Daten aus der Map
# ================================
karte = json.loads(response.text)
json.dump(karte,open('mir_map_karte.json','w'),indent = 4,sort_keys = True)

# ================================
#  Bild Daten aus der Map
# ================================
karte_map = karte["map"].encode('utf-8')
decoded_karte_map = base64.decodebytes(karte_map)

with open('mir_map.png', 'wb') as file_to_save:
    file_to_save.write(decoded_karte_map)

# ================================
#  Meta Daten
#  JSON Daten mit weiteren Bildern und Infos
# ================================
karte_metadata = karte["metadata"].encode('utf-8')
decoded_karte_metadata = base64.decodebytes(karte_metadata)

json.dump(json.loads(decoded_karte_metadata),open('mir_map_karte_metadata.json','w'),indent = 4,sort_keys = True)

# ================================
#  Bild Daten aus one_way_map
# ================================
karte_map_oneWayMap = karte["one_way_map"].encode('utf-8')
decoded_karte_map_oneWayMap = base64.decodebytes(karte_map_oneWayMap)

with open('mir_map__oneWayMap.png', 'wb') as file_to_save:
    file_to_save.write(decoded_karte_map)

# =====================================
#  Bild Daten aus den Metadaten bereich
# =====================================
karte_metadata_json = json.loads(decoded_karte_metadata)

karte_map_base_map_floor = karte_metadata_json["base_map_floor"].encode('utf-8')
decoded_karte_map_base_map_floor = base64.decodebytes(karte_map_base_map_floor)

with open('mir_map_base_map_floor.png', 'wb') as file_to_save:
    file_to_save.write(decoded_karte_map_base_map_floor)


karte_map_base_map_walls = karte_metadata_json["base_map_walls"].encode('utf-8')
decoded_karte_map_base_map_walls = base64.decodebytes(karte_map_base_map_walls)

with open('mir_map_base_map_walls.png', 'wb') as file_to_save:
    file_to_save.write(decoded_karte_map_base_map_walls)


    
