import requests
import json

url = "http://192.168.202.131/api/v2.0.0/status"

payload  = {}
headers = {
  'Authorization': 'Basic YWRtaW46OGM2OTc2ZTViNTQxMDQxNWJkZTkwOGJkNGRlZTE1ZGZiMTY3YTljODczZmM0YmI4YTgxZjZmMmFiNDQ4YTkxOA=='
}

response = requests.request("GET", url, headers=headers, data = payload)

print("Status: " + response.status_code)
print(response.json())

json.dump(parsed,open('mir_status_response.json','w'),indent=4,sort_keys=True)
