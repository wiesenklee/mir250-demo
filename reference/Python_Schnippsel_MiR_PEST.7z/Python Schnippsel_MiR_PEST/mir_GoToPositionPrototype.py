import requests
import json

url = "http://192.168.202.131/api/v2.0.0/mission_queue"

payload = "{\"mission_id\": \"mirconst-guid-0000-0003-actionlist00\",\"ordered\": \"2021-02-06T23:26:55\",\"parameters\": [{\"id\": \"X\",\r\n      \"label\": \"31.85\",\r\n      \"value\": 31.85\r\n    },\r\n    {\r\n      \"id\": \"Y\",\r\n      \"label\": \"34.15\",\r\n      \"value\": 34.15\r\n    },\r\n    {\r\n      \"id\": \"Orientation\",\r\n      \"label\": \"8.85795876\",\r\n      \"value\": 8.85795876\r\n    }\r\n  ]\r\n  }"
headers = {
  'Authorization': 'Basic YWRtaW46OGM2OTc2ZTViNTQxMDQxNWJkZTkwOGJkNGRlZTE1ZGZiMTY3YTljODczZmM0YmI4YTgxZjZmMmFiNDQ4YTkxOA==',
  'Content-Type': 'application/json'
}

 response = requests.request("POST", url, headers=headers, data = payload)
 print(response.text.encode('utf8'))
